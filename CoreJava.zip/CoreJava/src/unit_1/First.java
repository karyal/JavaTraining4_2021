package unit_1;

public class First {
	public static void main(String[] args) {
		System.out.println("Hello world of Java");
		System.out.println("Hi");
		System.out.println("How are you?");
	}
}